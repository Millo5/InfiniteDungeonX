# Boulders Resourcepack

## Custom Characters

[List of replaceable characters.](https://old.unicode-table.com/en/blocks/private-use-area/)

### Custom Gui's
Copy and add gui character for custom gui:
"&f"

### Used Characters
>
> #### General Utility
> - U+E000  : Negative space
> - U+E00A  : Negative space x100
>
> #### Gui's
> - U+E001  : Pouch
> > - U+E003  : button layer 1
> > - U+E004  : button layer 2
> > - U+E005  : button layer 3
>
> - U+0002  : Settings
>
> #### Chat Tags
> - U+E100  : Dev
> - U+E101  : Builder
> - U+E102  : Watcher
> - U+E103  : Onion
> - U+E104  : Player
>
> #### Emotes
> - Just look in the font and the image file i cant be botherd
>
> #### Misc
> - U+E400  : Cloud Left
> - U+E401  : Cloud Right
> - U+E402  : Subscript Slash
> - U+E402  : Subscript Slash
>
> - U+E403  : Loading Bar (background)
. - U+E404  : Emo Menu Mid (background)
. - U+E405  : Emo Menu Top (background)
. - U+E407  : Emo Menu Bot (background)
>
> - U+E406  : Head Chat Bar